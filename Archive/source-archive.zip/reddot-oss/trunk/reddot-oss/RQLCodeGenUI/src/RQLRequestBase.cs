/*
 * Created by SharpDevelop.
 * User: Nick
 * Date: 2/22/2007
 * Time: 3:53 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;

namespace RQL
{
	/// <summary>
	/// Description of RQLRequestBase.
	/// </summary>
	public class RQLRequestBase
	{
		public RQLRequestBase()	{}
	}
}

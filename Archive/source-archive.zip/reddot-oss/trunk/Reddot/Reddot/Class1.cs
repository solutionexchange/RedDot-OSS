using System;
using System.Collections.Generic;
using System.Text;

namespace Reddot
{
    public class Class1
    {
    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace Reddot
{
    class RQLResponse
    {
        private string _Response;

        public RQLResponse( string Response )
        {
            _Response = Response;
        }
    }
}
